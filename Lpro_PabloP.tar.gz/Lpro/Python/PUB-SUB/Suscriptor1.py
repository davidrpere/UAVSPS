#!/usr/bin/python
import zmq
from wifi import Cell, Scheme
import base64
import json


context = zmq.Context()
socket = context.socket(zmq.SUB)
socket.connect("tcp://127.0.0.1:5000")
socket.setsockopt(zmq.SUBSCRIBE, "Dron1")

socket_send = context.socket(zmq.PUB)
socket_send.bind("tcp://127.0.0.1:5001")

ident="1"
wifi=""
pos="Base -1234 +1234"
with open("/home/pablo/Descargas/hobbit.jpg","rb") as imageFile:
 strn=base64.b64encode(imageFile.read())


while True:
 print "->",socket.recv()
 cell = Cell.all('wlp5s0');
 var=0;
 while (var!=len(cell)):
  wifi=wifi+cell[var].ssid+str(cell[var].signal)
  var=var+1
 d = {"dron": ident, "Wifi": wifi, "Posicion": pos, "Imagen":strn}
 p=json.dumps(d)
 socket_send.send_string(p)
 wifi=""
 
 

