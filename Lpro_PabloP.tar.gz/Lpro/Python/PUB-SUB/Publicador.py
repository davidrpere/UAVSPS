#!/usr/bin/env python
import zmq
from time import sleep
import base64
import json
from PIL import Image

context = zmq.Context()
socket = context.socket(zmq.PUB)
socket.bind("tcp://127.0.0.1:5000")

socket_rec = context.socket(zmq.SUB)
socket_rec.connect("tcp://127.0.0.1:5001")
socket_rec.setsockopt(zmq.SUBSCRIBE, "")

while True:
 sleep(1)
 msg="Dron2 avanzar a posicion -123123.312 +12312.231"
 socket.send(msg)
 msg="Dron1 sacar foto"
 socket.send(msg)
 sleep(2)
 rec=socket_rec.recv()
 data=json.loads(rec)



 fh = open("/home/pablo/Descargas/recibida.jpg", "wb")
 fh.write(data["Imagen"].decode('base64'))
 fh.close()
 imagen = Image.open("/home/pablo/Descargas/recibida.jpg")
 imagen.show()


 print data["dron"]+data["Wifi"]+data["Posicion"]+data["Bateria"]
 
 
 
""" para decodificar una imagen enviada
 fh = open("/home/pablo/Descargas/recibida.jpg", "wb")
 fh.write(rec.decode('base64'))
 fh.close()
 imagen = Image.open("/home/pablo/Descargas/recibida.jpg")
 imagen.show() """
 	
  

