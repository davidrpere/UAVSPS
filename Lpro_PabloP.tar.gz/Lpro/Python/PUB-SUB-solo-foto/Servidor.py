#!/usr/bin/python
import zmq
import base64
import json
#from picamera import PiCamera


context = zmq.Context()
socket = context.socket(zmq.REP)
socket.bind("tcp://127.0.0.1:8081")


socket_camara = context.socket(zmq.PUB)
socket_camara.bind("tcp://127.0.0.1:8082")


#with open("/home/pablo/Descargas/hobbit.jpg","rb") as imageFile:
#	strn=base64.b64encode(imageFile.read())


while True:
	# Esperar por peticion:
	message = socket.recv()
	datos = message.split(" ")
	ident=datos[0]
	print("Recibida peticion: %s" % message)


	# Sacar foto y enviar:
	# TODO -> foto a variable imagen	
	#d = {"dron": ident, "Posicion": (datos[1],datos[2],datos[3]), "Imagen":base64.b64encode(imagen)}
	#p=json.dumps(d)
	socket_camara.send_string("Hola")

	# Enviar confirmacion:
	print("Enviando confirmacion:", message)
	socket.send_string(message)

