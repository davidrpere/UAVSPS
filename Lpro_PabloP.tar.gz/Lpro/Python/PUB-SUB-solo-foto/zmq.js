
	   zmq=require("zeromq");
       var socket = zmq.socket('sub');
	   socket.identity = 'subscriber' + process.pid;
 	   socket.connect("127.0.0.1:8082");
 	   socket.subscribe('1');
console.log('connected!');

 socket.on('message', function(data) {
   console.log(socket.identity + ': received data ' + data.toString());
});

    
