a = 0
while True:
	cell = Cell.all('wlp5s0');
	var=0;
	b = clock()
	if b - a > 2:
		while (var!=len(cell)):
			print "Nombre de la red:",cell[var].signal,"y",cell[var].ssid,"dbm"
			var=var+1
		a=b
