from wifi import Cell, Scheme
import zmq
from time import sleep
context = zmq.Context()
socket = context.socket(zmq.PUB)
socket.bind("tcp://127.0.0.1:5001")

while True:
	cell = Cell.all('wlp5s0');
	var=0;
	sleep(0.5)
	while (var!=len(cell)):
		socket.send_string(cell[var].ssid,cell[var].signal)
		print "Nombre de la red:",cell[var].signal,"y",cell[var].ssid,"dbm"
		var=var+1
		



