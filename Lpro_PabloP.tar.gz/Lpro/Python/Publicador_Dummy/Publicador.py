#!/usr/bin/env python
import zmq
from time import sleep
import base64
import json
from PIL import Image

ip1="192.168.43.219";
ip2="192.168.43.27";
context = zmq.Context()

var req_algoritmo_genetico = zmq.socket('req');
req_algoritmo_genetico.connect("tcp://localhost:7777");


var req_dron1_envio_waypoints = zmq.socket('req');
var sub_dron1_latlng = zmq.socket('sub');
var sub_dron1_orientacion = zmq.socket('sub');
var sub_dron1_foto = zmq.socket('sub');

req_dron1_envio_waypoints.connect("tcp://%s:5558",ip1);
sub_dron1_latlng.connect("tcp://%s:5557",ip1);
sub_dron1_orientacion.connect("tcp://%s:5560",ip1);
sub_dron1_foto.connect('tcp://192.168.43.219:8999');

sub_dron1_latlng.subscribe('');
sub_dron1_orientacion.subscribe('');
sub_dron1_foto.subscribe('');


while True:
 sleep(1)
 socket.send(msg)
 socket.send(msg)
 sleep(2)
 rec=socket_rec.recv()
 data=json.loads(rec)





 print data["dron"]+data["Wifi"]+data["Posicion"]+data["Bateria"]
 
 
 
""" para decodificar una imagen enviada
 fh = open("/home/pablo/Descargas/recibida.jpg", "wb")
 fh.write(rec.decode('base64'))
 fh.close()
 imagen = Image.open("/home/pablo/Descargas/recibida.jpg")
 imagen.show() """
 	
  

