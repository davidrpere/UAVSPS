from UAV import UAV

dron = UAV(1, "", [0,0], 5)

dron.startBucleMision()
