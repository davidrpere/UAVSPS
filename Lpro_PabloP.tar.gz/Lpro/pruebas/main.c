#include  <stdio.h>
#include  <string.h>
#include  <stdlib.h>
#include  <errno.h>
#include  <glib.h>
#include  <gio / gio.h>

#define BLUEZ_BUS_NAME "org.bluez"
#define BLUEZ_INTF_ADAPTER "org.bluez.Adapter"

static  GDBusConnection  * dbus_conn  =  NULL ;
static  GMainLoop  * main_loop ;

struct  handler_data  {
  const  char  * bt_address ;
   rssi corto ;
};

/ *
 * Función de devolución de llamada para la señal DeviceFound de org.bluez.Adapter
 * interfaz.
 * /
 vacío estático
device_found_handler  ( conexión GDBusConnection  * ,
                        const  gchar  * sender_name ,
                        const  gchar  * object_path ,
                        const  gchar  * interface_name ,
                        const  gchar  * signal_name ,
                        GVariant  * parámetros ,
                        gpointer  user_data )
{
  char  * device_address ;
  gboolean  res ;
   rssi corto ;
  GVariant  * property_dict ;
  struct  handler_data  * data  =  ( struct  handler_data  * ) user_data ;

  / *
   * Formato de parámetro: sa {sv}
   * Solo está interesado en el RSSI, así que busca esa entrada en las propiedades
   * diccionario.
   * /
  g_variant_get ( parameters ,  "(& s *)" ,  & device_address ,  & property_dict );

  if  ( strcmp ( data -> bt_address ,  device_address ))  {
    / * No es el dispositivo de interés * /
    regreso ;
  }

  res  =  g_variant_lookup ( property_dict ,  "RSSI" ,  "n" ,
			 & rssi );
  if  ( ! res )  {
    printf ( "No se puede obtener la dirección del dispositivo de dbus \ n " );
    g_main_loop_quit ( main_loop );
    regreso ;
  }
  
  datos -> rssi  =  rssi ;
  g_main_loop_quit ( main_loop );
}

/ *
 * Obtiene el RSSI para una dirección de dispositivo BT determinada.
 * /
 corto estático
get_rssi ( const  char  * bt_address )
{
  GError  * error  =  NULL ;
  GVariant  * reply  =  NULL ;
  char  * adapter_object  =  NULL ;
   datos de struct handler_data  ;
  
  datos . bt_address  =  bt_address ;

  main_loop  =  g_main_loop_new ( NULL ,  FALSE );
  if  ( ! main_loop )  {
    printf ( "Error al crear el bucle principal \ n " );
    return  0 ;
  }

  dbus_conn  =  g_bus_get_sync ( G_BUS_TYPE_SYSTEM ,  NULL ,  & error );
  if  ( error )  {
    printf ( "No se puede obtener la conexión dbus \ n " );
    return  0 ;
  }

  / * Obtenga el adaptador BT predeterminado. Necesario para iniciar el descubrimiento del dispositivo * /
  reply  =  g_dbus_connection_call_sync ( dbus_conn ,
				      BLUEZ_BUS_NAME ,
				      "/" ,
				      "org.bluez.Manager" ,
				      "DefaultAdapter" ,
				      NULL , 
				      G_VARIANT_TYPE ( "(o)" ),
				      G_DBUS_CALL_FLAGS_NONE ,
				      - 1 ,
				      NULL ,
				      y error );

  if  ( error )  {
    printf ( "No se pueden obtener objetos gestionados:% s \ n " ,  error -> mensaje );
    return  0 ;
  }
  g_variant_get ( reply ,  "(& o)" ,  y adapter_object );

  / * Registre un controlador para las señales DeviceFound para leer el dispositivo RSSI * /
  g_dbus_connection_signal_subscribe ( dbus_conn ,
				     NULL ,
				     "org.bluez.Adapter" ,
				     "DeviceFound" ,
				     NULL ,
				     NULL ,
				     0 ,
				     device_found_handler ,
				     y datos ,
				     NULL );

  / * Iniciar descubrimiento de dispositivo * /
  reply  =  g_dbus_connection_call_sync ( dbus_conn ,
				     BLUEZ_BUS_NAME ,
				     adaptador_objeto ,
				     "org.bluez.Adapter" ,
				     "StartDiscovery" ,
				     NULL ,
				     NULL ,
				     G_DBUS_CALL_FLAGS_NONE ,
				     - 1 ,
				     NULL ,
				     y error );

  if  ( error )  {
    printf ( "No se puede iniciar el descubrimiento:% s \ n " ,  error -> mensaje );
    return  0 ;
  }

  g_main_loop_run ( main_loop );

  devolver  los datos . rssi ;
}

En t
main  ( int  argc ,  char  ** argv )
{
   rssi  corto =  0 ;

  if  ( argc  ! =  2 )  {
    printf ( "Uso:% s <direcciones de bt> \ n " ,  argv [ 0 ]);
    return  - 1 ;
  }

  while  ( 1 )  {
    rssi  =  get_rssi ( argv [ 1 ]);
    printf ( "Dispositivo% s, rssi =% d \ n " ,  argv [ 1 ],  rssi );
  }

  return  0 ;
}
