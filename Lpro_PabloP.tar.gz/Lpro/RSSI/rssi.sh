#!/bin/bash
echo "testing rssi /n"> logs1
while (true)
do
hcitool rssi 00:1E:7C:2E:C6:23>> logs1
date +%S>> logs1
sleep 0.25
done
