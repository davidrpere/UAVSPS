//
//  Weather update client in C++
//  Connects SUB socket to tcp://localhost:5556
//  Collects weather updates and finds avg temp in zipcode
//
//  Olivier Chamoux <olivier.chamoux@fr.thalesgroup.com>
//
#include <zmq.hpp>
#include <iostream>
#include <sstream>
#include <jsoncpp/json/json.h>
#include <typeinfo>

int main (int argc, char *argv[])
{
    zmq::context_t context (1);

    std::cout << "Collecting updates from weather server...\n" << std::endl;
    zmq::socket_t subscriber (context, ZMQ_SUB);
    subscriber.connect("tcp://127.0.0.1:8081"); 

	const char *filter = "";
    subscriber.setsockopt(ZMQ_SUBSCRIBE, filter, strlen (filter));


        zmq::message_t update;
        int zipcode, temperature, relhumidity;
		std::string hola1;
        subscriber.recv(&update);

        //std::istringstream iss(static_cast<char*>(update.data()));
		//iss >> hola1;
        //std::cout << std::string(static_cast<char*>(update.data()), update.size()) << std::endl;
		

//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	std::string strJson =std::string(static_cast<char*>(update.data()), update.size())	;
	Json::Value root;
    Json::Reader reader;
	reader.parse(strJson.c_str(),root);
    Json::FastWriter fastwriter;
	std::cout<<root<<std::endl;
	std::cout << root["Waypoints"] <<std::endl; 

//---------------------------------------------------------------------------------------------------------------------   

    return 0;
}
