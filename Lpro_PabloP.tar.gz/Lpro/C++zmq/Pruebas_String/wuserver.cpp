//
//  Weather update server in C++
//  Binds PUB socket to tcp://*:5556
//  Publishes random weather updates
//
//  Olivier Chamoux <olivier.chamoux@fr.thalesgroup.com>
//
#include <zmq.hpp>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <jsoncpp/json/json.h>
#include <typeinfo>

#define within(num) (int) ((float) num * random () / (RAND_MAX + 1.0))

int main () {

    zmq::context_t context (1);
    zmq::socket_t publisher (context, ZMQ_PUB);
    publisher.bind("tcp://127.0.0.1:8081");  

    while (1) {
		//char* hola="{\"Waypoints\":\"123 456 789\",\"Altitud\" : \"1000\" }";

	std::string strJson="{\"Waypoints\":\"123 456 789\",\"Altitud\" : \"1000\" }";
    Json::Value root;
    Json::Reader reader;
    reader.parse(strJson.c_str(),root);
    Json::FastWriter fastwriter;
    std::string escrito = fastwriter.write(root);
	const char* c = escrito.c_str();


        zmq::message_t message(200);
		snprintf ((char *) message.data(), 200 ,"%s", c);

        publisher.send(message);

    }
    return 0;
}
