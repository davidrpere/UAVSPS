#include <zmq.hpp>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int main () {

    zmq::context_t context (1);
    zmq::socket_t publisher (context, ZMQ_PUB);
    publisher.bind("tcp://127.0.0.1:8080");

    while (1) {

        int id, latitud, longitud;
        id     = 1;
        longitud = 1234;
        latitud = 12345;
        zmq::message_t message(25);
        snprintf ((char *) message.data(), 25 ,"%d %d %d %s", id, longitud, latitud, "hola");
        publisher.send(message);

    }
    return 0;
}
