#include <zmq.hpp>
#include <iostream>
#include <sstream>

int main ()
{
    zmq::context_t context (1);
    std::cout << "Collecting updates from WEB server...\n" << std::endl;
    zmq::socket_t subscriber (context, ZMQ_SUB);
    subscriber.connect("tcp://127.0.0.1:8080");

	const char *filter =  "1";
    subscriber.setsockopt(ZMQ_SUBSCRIBE, filter, strlen (filter));

        zmq::message_t update;
		int id;
        double   latitud, longitud,altitud;
        subscriber.recv(&update);

        std::istringstream iss(static_cast<char*>(update.data()));
		iss >> id >> latitud >> longitud >>altitud ;

        std:: cout << "\nel ID del dron es: " <<id << std::endl;
		std:: cout << "\nla Latitud es: " <<latitud << std::endl;
		std:: cout << "\nel Longitud es: " <<longitud << std::endl;
		std:: cout   <<"\n la Altitud es: " <<altitud <<std::endl;
    
    return 0;
}
