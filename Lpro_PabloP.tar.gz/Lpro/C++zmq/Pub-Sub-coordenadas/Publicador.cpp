#include <zmq.hpp>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int main () {

    zmq::context_t context (1);
    zmq::socket_t publisher (context, ZMQ_PUB);
    publisher.bind("tcp://127.0.0.1:8080");
	int id=1;
	double latitud= 123;
	double longitud= 456;
	double altitud= 789;
while(1){
    int size=0;
	size=sizeof(id)+sizeof(latitud)+sizeof(longitud)+sizeof(altitud)+1;
	zmq::message_t message(size);
    snprintf((char *) message.data(), size ,
        "%i %f %f %f",id, latitud, longitud, altitud);
    publisher.send(message);
}
    return 0;
}
