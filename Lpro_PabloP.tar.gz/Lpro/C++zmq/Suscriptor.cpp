#include <zmq.hpp>
#include <iostream>
#include <sstream>

int main ()
{
    zmq::context_t context (1);
    std::cout << "Collecting updates from weather server...\n" << std::endl;
    zmq::socket_t subscriber (context, ZMQ_SUB);
    subscriber.connect("tcp://127.0.0.1:8080");

	const char *filter =  "1";
    subscriber.setsockopt(ZMQ_SUBSCRIBE, filter, strlen (filter));

        zmq::message_t update;
        int  id, latitud, longitud;
		std::string hola;
        subscriber.recv(&update);

        std::istringstream iss(static_cast<char*>(update.data()));
		iss >> id >> latitud >> longitud >>hola ;

        std:: cout << "el ID del dron es: " <<id << std::endl;
		std:: cout << "la Temperatura es: " <<latitud << std::endl;
		std:: cout << "el humedad es: " <<longitud << std::endl;
		std:: cout   <<hola << std::endl;
    
    return 0;
}
