#include <zmq.hpp> 
#include <string>
#include <iostream>
#include <sstream>
#include <jsoncpp/json/json.h>
#include <typeinfo>

int main () {
	
	zmq::context_t context (1);
    zmq::socket_t publisher (context, ZMQ_PUB);
    publisher.bind("tcp://127.0.0.1:8081");   	
	int id=1;
	
    std::string strJson="{\"Waypoints\":\"123 456 789\",\"Altitud\" : \"1000\" }";
    Json::Value root;
    Json::Reader reader;
    reader.parse(strJson.c_str(),root);
    Json::FastWriter fastwriter;
    std::string message = fastwriter.write(root);

	//const char * c = message.c_str();
	char* hola="hola";
	//std::cout<<c<<std::endl;

	zmq::message_t mensa (200);
    snprintf((char *) mensa.data(), 200 ,"%s",hola);
	
	while(1){
    	publisher.send(mensa);
	}
    return 0;
}
