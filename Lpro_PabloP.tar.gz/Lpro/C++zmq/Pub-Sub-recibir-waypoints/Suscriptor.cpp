#include <zmq.hpp> 
#include <string>
#include <iostream>
#include <sstream>
#include <jsoncpp/json/json.h>
#include <typeinfo>

int main () {
	
	zmq::context_t context (1);
    std::cout << "Collecting updates from WEB server...\n" << std::endl;
    zmq::socket_t suscriber (context, ZMQ_SUB);
    suscriber.connect("tcp://127.0.0.1:8081");

	const char *filter =  "";
    suscriber.setsockopt(ZMQ_SUBSCRIBE, filter, strlen (filter));

	Json::Value root;
    Json::Reader reader;
	std::string strJson;

	std::string hola;

    zmq::message_t update;
    suscriber.recv(&update);


	std::istringstream iss(static_cast<char*>(update.data()));
    iss >> hola ;
	std:: cout   <<hola <<std::endl;
	
    return 0;
}

